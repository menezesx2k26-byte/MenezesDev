# MenezesDev Brand Kit

Estrutura pronta para adicionar ao repositório.

```text
public/assets/brand/
├── logo-dark.png
├── logo-light.png
├── logo-mark-dark.png
├── logo-mark-light.png
├── wordmark-dark.png
├── wordmark-light.png
├── favicon-32.png
├── apple-touch-icon.png
└── brand-icon-512.png

docs/brand/
└── BRAND_GUIDE.md
```

### Convenção
- `dark` = asset destinado a fundo escuro.
- `light` = asset destinado a fundo claro.

Os PNGs possuem transparência quando aplicável. Os ícones menores usam o background oficial `#08080D`.
