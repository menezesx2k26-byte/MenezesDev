# MenezesDev — Brand Guide

**Marca:** MenezesDev  
**Tagline:** Sites que impulsionam negócios.

## Direção visual
Marca dark-first, tecnológica, profissional e sóbria. Evitar estética gamer/cyberpunk, excesso de glow, neon, glassmorphism e aparência de template genérico.

## Paleta
- Background: `#08080D`
- Surface: `#101016`
- Surface elevated: `#171720`
- Texto: `#F7F7FA`
- Texto secundário: `#A5A5B3`
- Roxo principal: `#7617FF`
- Violeta: `#9827FF`
- Magenta: `#E13EFF`
- Border: `rgba(255,255,255,.08)`
- Gradiente oficial: `#6F16FF → #E13EFF`

## Tipografia
- Headings/display: **Manrope** 600–800
- Corpo/UI: **Inter** 400–600

## Uso
- `logo-dark.png`: fundo escuro
- `logo-light.png`: fundo claro
- `logo-mark-dark.png`: monograma para fundo escuro
- `logo-mark-light.png`: monograma para fundo claro
- `wordmark-dark.png`: wordmark para fundo escuro
- `wordmark-light.png`: wordmark para fundo claro

A tagline deve permanecer separada da logo principal.

## Importante
Os arquivos deste pacote são as versões raster aprovadas para prototipagem e implementação inicial.
O SVG mestre deve ser vetorizado posteriormente mantendo exatamente a geometria aprovada.
